﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Socar.Data
{
    public class DefectData : EntityData<Defect>
    {
        public Defect Get(int defectId)
        {
            SocarEntities context = CreateContext();
            return context.Defects.FirstOrDefault(x => x.DefectId == defectId);
        }
    }
}
