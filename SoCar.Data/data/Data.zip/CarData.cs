﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Socar.Data
{
    public class CarData : EntityData<Car>
    {
        public Car Get(int carId)
        {
            SocarEntities context = CreateContext();
            return context.Cars.FirstOrDefault(x => x.CarId == carId);
        }
    }
}
