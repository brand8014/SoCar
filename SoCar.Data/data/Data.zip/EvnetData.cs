﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Socar.Data.Data
{
    public class EvnetData : EntityData<Event>
    {
        public Event Get(int eventId)
        {
            SocarEntities context = CreateContext();
            return context.Events.FirstOrDefault(x => x.EventId == eventId);
        }
    }
}
