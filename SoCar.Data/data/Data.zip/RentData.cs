﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Socar.Data
{
    public class RentData : EntityData<Rent>
    {
        public Rent Get(int rentId)
        {
            SocarEntities context = CreateContext();
            return context.Rents.FirstOrDefault(x => x.RentId == rentId);
        }
    }
}
