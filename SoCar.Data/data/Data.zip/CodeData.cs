﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Socar.Data.Data
{
    public class CodeData : EntityData<Code>
    {
        public Code Get(int codeId)
        {
            SocarEntities context = CreateContext();
            return context.Codes.FirstOrDefault(x => x.CodeId == codeId);
        }
    }
}
